import $ from "jquery"; // this is referencing to the gulp externals (script task)
let x = 0;

// $('body').click(() => {
//     alert(true);
// })