<?php 
    function _premiumtheme_assets() {
        wp_enqueue_style( '_premiumtheme-stylesheet', get_template_directory_uri() . '/dist/assets/css/bundle.css', [], '1.0.0', 'all' );
        wp_enqueue_script( '_premiumtheme-stylesheet', get_template_directory_uri() . '/dist/assets/js/bundle.js', ['jquery'], '1.0.0', true );
        // wp_enqueue_script( 'jquery' );
    }

    add_action('wp_enqueue_scripts', '_premiumtheme_assets');

    function _premiumtheme_admin_assets() {
        wp_enqueue_style( '_premiumtheme-admin-stylesheet', get_template_directory_uri() . '/dist/assets/css/bundle.css', [], '1.0.0', 'all' );

        wp_enqueue_script( '_premiumtheme-admin-scripts', get_template_directory_uri() . '/dist/assets/js/admin.js', [], '1.0.0', true );
    }

    add_action('admin_enqueue_scripts', '_premiumtheme_admin_assets');
?>